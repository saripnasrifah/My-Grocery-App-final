// import 'dart:js';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

// 📦 Local imports
import 'package:my_grocery_app/app_drawer.dart';
import 'package:my_grocery_app/cart.dart';
import 'package:my_grocery_app/info.dart';
import 'package:my_grocery_app/newsstand.dart';
import 'package:my_grocery_app/profile.dart';
import 'package:my_grocery_app/shop.dart';
import 'package:my_grocery_app/provider.dart'; // CartProvider
import 'package:my_grocery_app/favorite_provider.dart'; //  FavoriteProvider

void main() {
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (context) => CartProvider()),
        ChangeNotifierProvider(
            create: (context) => FavoriteProvider()), //  Added
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'My Shoe Shop',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff003ab7)),
      ),
      home: const MyHomePage(title: 'My Shoe Shop'),
      routes: {
        '/shop': (context) => const Shop(),
        '/newsstand': (context) => const Newsstand(),
        '/info': (context) => const Info(),
        '/myprofile': (context) => const MyProfile(),
        //'/myfavorite': (context) => const FavoriteProvider(),
        '/cart': (context) => const Cart(),
      },
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});
  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('My Shoe Shop')),
      drawer: const AppDrawer(),
      body: const Center(
        child: Text(
          'Welcome to My Shoe Shop 👟',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500),
        ),
      ),
    );
  }
}
